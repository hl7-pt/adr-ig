# message - HL7 Portugal FHIR Implementation Guide para alergias e reacções adversas ao medicamento v1.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **message**

## Example Bundle: message



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "message",
  "identifier" : {
    "system" : "urn:example-org:sender.identifiers",
    "value" : "efdd254b-0e09-4164-883e-35cf3871715f"
  },
  "type" : "message",
  "timestamp" : "2015-07-14T11:15:33+10:00",
  "entry" : [{
    "fullUrl" : "http://example.org/MessageHeader/messageheader1",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "messageheader1",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_messageheader1\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MessageHeader messageheader1</b></p><a name=\"messageheader1\"> </a><a name=\"hcmessageheader1\"> </a><p><b>event</b>: example.org: ADR (Reacção Adversa)</p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td></tr><tr><td style=\"display: none\">*</td><td>Reporter</td></tr></table><p><b>focus</b>: </p><ul><li><a href=\"AdverseEvent-Notifi-2.html\">AdverseEvent Pyrexia</a></li><li><a href=\"Patient-pat-1.html\">Américo  Male, DoB: 1980-01-01</a></li><li><a href=\"Practitioner-not-1.html\">Sandra</a></li><li><a href=\"MedicationStatement-medinfo-1.html\">MedicationStatement: status = recorded; effective[x] = 2024-11-01</a></li><li><a href=\"Medication-med1.html\">Medication Evrysdi / Risdiplam</a></li></ul></div>"
      },
      "eventCoding" : {
        "system" : "http://example.org",
        "code" : "ADR",
        "display" : "Reacção Adversa"
      },
      "source" : {
        "name" : "Reporter"
      },
      "focus" : [{
        "reference" : "AdverseEvent/Notifi-2"
      },
      {
        "reference" : "Patient/pat-1"
      },
      {
        "reference" : "Practitioner/not-1"
      },
      {
        "reference" : "MedicationStatement/medinfo-1"
      },
      {
        "reference" : "Medication/med1"
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/AdverseEvent/Notifi-2",
    "resource" : {
      "resourceType" : "AdverseEvent",
      "id" : "Notifi-2",
      "meta" : {
        "profile" : ["https://hl7.pt/fhir/ADR/StructureDefinition/ReacaoAdversa"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdverseEvent_Notifi-2\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: AdverseEvent Notifi-2</b></p><a name=\"Notifi-2\"> </a><a name=\"hcNotifi-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ReacaoAdversa.html\">Perfil para notificação de RAM</a></p></div><p><b>identifier</b>: <code>http:/example.org</code>/2</p><p><b>status</b>: Completed</p><p><b>actuality</b>: Adverse Event</p><p><b>code</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/MDRPOR 10037660}\">Pyrexia</span></p><p><b>subject</b>: <a href=\"Patient-pat-1.html\">Américo  Male, DoB: 1980-01-01</a></p><p><b>detected</b>: 2024-11-14</p><p><b>recordedDate</b>: 2024-11-14</p><p><b>seriousness</b>: <span title=\"Códigos:{https://hl7.pt/fhir/ADR/CodeSystem/adr-gravidade-cs HOSP}\">Hospitalização</span></p><p><b>recorder</b>: <a href=\"Practitioner-not-1.html\">Sandra</a></p><h3>SuspectEntities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Instance[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"MedicationStatement-medinfo-1.html\">MedicationStatement: status = recorded; effective[x] = 2024-11-01</a></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http:/example.org",
        "value" : "2"
      }],
      "status" : "completed",
      "actuality" : "actual",
      "code" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/MDRPOR",
          "code" : "10037660",
          "display" : "Pyrexia"
        }]
      },
      "subject" : {
        "reference" : "Patient/pat-1"
      },
      "detected" : "2024-11-14",
      "recordedDate" : "2024-11-14",
      "seriousness" : {
        "coding" : [{
          "system" : "https://hl7.pt/fhir/ADR/CodeSystem/adr-gravidade-cs",
          "code" : "HOSP",
          "display" : "Hospitalização"
        }]
      },
      "recorder" : {
        "reference" : "Practitioner/not-1"
      },
      "suspectEntity" : [{
        "instanceReference" : {
          "reference" : "MedicationStatement/medinfo-1"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Patient/pat-1",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "pat-1",
      "meta" : {
        "profile" : ["https://hl7.pt/fhir/ADR/StructureDefinition/Doente"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_pat-1\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Patient pat-1</b></p><a name=\"pat-1\"> </a><a name=\"hcpat-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-Doente.html\">Perfil para notificação de RAM - Doente</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Américo  Male, DoB: 1980-01-01</p><hr/></div>"
      },
      "name" : [{
        "given" : ["Américo"]
      }],
      "gender" : "male",
      "birthDate" : "1980-01-01"
    }
  },
  {
    "fullUrl" : "http://example.org/Practitioner/not-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "not-1",
      "meta" : {
        "profile" : ["https://hl7.pt/fhir/ADR/StructureDefinition/ProfissionalSaude"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_not-1\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Practitioner not-1</b></p><a name=\"not-1\"> </a><a name=\"hcnot-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ProfissionalSaude.html\">Perfil para notificação de RAM - Profissional de saúde</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Sandra</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Practitioner\">Detalhes do contacto</td><td colspan=\"3\"><a href=\"mailto:exemplo@exemplo.org\">exemplo@exemplo.org</a></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Certification, licensure, or training pertaining to the provision of care\">Qualification:</td><td colspan=\"3\"><span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/v2-0360 PA}\">Physician Assistant</span></td></tr></table></div>"
      },
      "name" : [{
        "given" : ["Sandra"]
      }],
      "telecom" : [{
        "system" : "email",
        "value" : "exemplo@exemplo.org",
        "use" : "work"
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0360",
            "code" : "PA",
            "display" : "Physician Assistant"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/MedicationStatement/medinfo-1",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "medinfo-1",
      "meta" : {
        "profile" : ["https://hl7.pt/fhir/ADR/StructureDefinition/InformacaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_medinfo-1\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationStatement medinfo-1</b></p><a name=\"medinfo-1\"> </a><a name=\"hcmedinfo-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-InformacaoMedicamento.html\">Perfil para notificação de RAM - medicamento</a></p></div><p><b>status</b>: Recorded</p><h3>Medications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Medication-med1.html\">Medication Evrysdi / Risdiplam</a></td></tr></table><p><b>subject</b>: <a href=\"Patient-pat-1.html\">Américo  Male, DoB: 1980-01-01</a></p><p><b>effective</b>: 2024-11-01</p><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Route</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://example.org 1}\">Oral</span></td></tr></table></div>"
      },
      "status" : "recorded",
      "medication" : {
        "reference" : {
          "reference" : "Medication/med1"
        }
      },
      "subject" : {
        "reference" : "Patient/pat-1"
      },
      "effectiveDateTime" : "2024-11-01",
      "dosage" : [{
        "route" : {
          "coding" : [{
            "system" : "http://example.org",
            "code" : "1",
            "display" : "Oral"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Medication/med1",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "med1",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_med1\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication med1</b></p><a name=\"med1\"> </a><a name=\"hcmed1\"> </a><p><b>code</b>: <span title=\"Códigos:{http://example.org 1}\">Evrysdi / Risdiplam</span></p><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td></tr><tr><td style=\"display: none\">*</td><td>a11234</td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://example.org",
          "code" : "1",
          "display" : "Evrysdi / Risdiplam"
        }]
      },
      "batch" : {
        "lotNumber" : "a11234"
      }
    }
  }]
}

```
